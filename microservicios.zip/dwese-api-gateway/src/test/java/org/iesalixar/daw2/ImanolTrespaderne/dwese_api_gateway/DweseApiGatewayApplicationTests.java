package org.iesalixar.daw2.ImanolTrespaderne.dwese_api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DweseApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
