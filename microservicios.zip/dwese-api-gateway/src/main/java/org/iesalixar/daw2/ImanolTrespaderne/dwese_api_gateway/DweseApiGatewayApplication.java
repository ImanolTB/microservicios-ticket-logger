package org.iesalixar.daw2.ImanolTrespaderne.dwese_api_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DweseApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(DweseApiGatewayApplication.class, args);
	}

}
