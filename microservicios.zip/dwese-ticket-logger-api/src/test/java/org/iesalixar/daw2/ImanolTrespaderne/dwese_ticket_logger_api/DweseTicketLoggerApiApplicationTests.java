package org.iesalixar.daw2.ImanolTrespaderne.dwese_ticket_logger_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DweseTicketLoggerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
