package org.iesalixar.daw2.ImanolTrespaderne.dwese_ticket_logger_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DweseTicketLoggerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DweseTicketLoggerApiApplication.class, args);
	}

}
