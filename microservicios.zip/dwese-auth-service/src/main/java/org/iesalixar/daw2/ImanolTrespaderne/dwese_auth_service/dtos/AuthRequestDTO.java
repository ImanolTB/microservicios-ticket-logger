package org.iesalixar.daw2.ImanolTrespaderne.dwese_auth_service.dtos;

import lombok.Data;

@Data
public class AuthRequestDTO {
    private String username;
    private String password;
}
