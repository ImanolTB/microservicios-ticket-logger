package org.iesalixar.daw2.ImanolTrespaderne.dwese_auth_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DweseAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DweseAuthServiceApplication.class, args);
	}

}
