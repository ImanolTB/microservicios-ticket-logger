package org.iesalixar.daw2.ImanolTrespaderne.dwese_auth_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DweseAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
